<?php
echo "<script>window.location = 'listar.php';</script>";