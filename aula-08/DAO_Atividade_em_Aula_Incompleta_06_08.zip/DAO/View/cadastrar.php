<?php
include "../Conexao.php";

include "../Classes/ContasPagar.php";
include "../DAO/ContasPagarDAO.php";

include "../Classes/ContasReceber.php";
include "../DAO/ContasReceberDAO.php";

if (isset($_GET['cadastroPagar'])) {
    $CP = new ContasPagar();
    $CP->setDocumento_contaspagar($_POST['txtDocumentoPagar']);
    $CP->setValor_contaspagar($_POST['txtValorPagar']);
    $CP->setFornecedor_contaspagar($_POST['cbFornecedorPagar']);
    $CP->setVencimento_contaspagar($_POST['txtDataPagar']);
    $CP->setStatus_contaspagar("N");

    $CPDAO = new ContasPagarDAO();

    if ($CPDAO->InsertContasPagar($CP)) {
        echo "<script>alert('Conta a pagar, cadastrada com succeso!');</script>";
        echo "<script>window.location = 'listar.php';</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CADASTRAR</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="text-slate-200 bg-slate-950">
    <div class="bg-black/30 flex flex-col gap-8 items-center justify-center min-h-screen">
        <div class="bg-slate-950 p-4 w-full max-w-[70%] rounded-md">
            <h2>Cadastro de contas a pagar</h2>
            <hr />

            <form action="?cadastroPagar" method="post">
                <table style="width: 100%" class="ms-classic3-main">
                    <tr>
                        <td style="width: 136px" class="ms-classic3-left">Fornecedor:</td>
                        <td>
                            <select class="bg-slate-900" name="cbFornecedorPagar">
                                <?php
                                $CP = new ContasPagar();
                                $CPDAO = new ContasPagarDAO();
                                foreach ($CPDAO->ShowFornecedores($CP) as $exibir) {
                                    echo $exibir;
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 136px" class="ms-classic3-left">Documento:</td>
                        <td class="ms-classic3-even"><input class="bg-slate-900" name="txtDocumentoPagar"
                                style="width: 127px" type="text" /></td>
                    </tr>
                    <tr>
                        <td style="width: 136px" class="ms-classic3-left">Valor:</td>
                        <td class="ms-classic3-even"><input class="bg-slate-900" name="txtValorPagar" style="width: 127px"
                                type="text" /></td>
                    </tr>
                    <tr>
                        <td style="width: 136px" class="ms-classic3-left">Data de Vencimento:</td>
                        <td class="ms-classic3-even"><input class="bg-slate-900" name="txtDataPagar" style="width: 127px"
                                type="text" /></td>
                    </tr>
                    <tr>
                        <td style="width: 136px" class="ms-classic3-left"> </td>
                        <td class="ms-classic3-even"><input class="bg-slate-900" name="btCadastrarPagar" type="submit"
                                value="Cadastrar" /></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</body>

</html>