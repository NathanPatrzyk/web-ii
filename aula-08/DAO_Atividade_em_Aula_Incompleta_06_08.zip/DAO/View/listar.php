<?php
include "../Conexao.php";

include "../Classes/ContasPagar.php";
include "../DAO/ContasPagarDAO.php";

include "../Classes/ContasReceber.php";
include "../DAO/ContasReceberDAO.php";
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>LISTAR</title>
</head>

<body class="text-slate-200 bg-slate-950">
    <div class="bg-black/30 flex flex-col gap-8 items-center justify-center min-h-screen">
        <div class="bg-slate-950 p-4 w-full max-w-[70%] rounded-md">
            <h2>Lista de Contas a Pagar</h2>
            <hr />
            <table class="ms-classic3-main flex flex-col gap-2" style="width: 77%">
                <tr class="flex justify-around">
                    <td class="ms-classic3-tl" style="width: 209px">Documento</td>
                    <td class="ms-classic3-top" style="width: 165px">Valor</td>
                    <td class="ms-classic3-top" style="width: 160px">Status</td>
                    <td class="ms-classic3-top" style="width: 66px">Opções</td>
                </tr>
                <?php

                $CP = new ContasPagar();
                $CPDAO = new ContasPagarDAO();

                $query = $CPDAO->ShowContasPagar($CP);

                while ($reg = $query->fetch_array()) {
                    ?>
                    <tr class="flex justify-around">
                        <td class="ms-classic3-left" style="width:209px">
                            <?= $reg["documento_contaspagar"]; ?>
                        </td>
                        <td class="ms-classic3-even" style="width: 165px">
                            <?= $reg["valor_contaspagar"]; ?>
                        </td>
                        <td class="ms-classic3-even" style="width: 160px">
                            <?= $reg["status_contaspagar"]; ?>
                        </td>
                        <td class="ms-classic3-even flex gap-1" style="width: 66px">
                            <a href="atualizarContaPagar.php?ID=<?= $reg["id_contaspagar"]; ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                    fill="none" stroke="#e2e8f0" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="lucide lucide-square-pen">
                                    <path d="M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                                    <path
                                        d="M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z" />
                                </svg>
                            </a>
                            <a href="apagarContaPagar.php?ID=<?= $reg["id_contaspagar"]; ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                    fill="none" stroke="#e2e8f0" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="lucide lucide-trash-2">
                                    <path d="M3 6h18" />
                                    <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                                    <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                                    <line x1="10" x2="10" y1="11" y2="17" />
                                    <line x1="14" x2="14" y1="11" y2="17" />
                                </svg>
                            </a>
                        </td>
                    </tr>
                <?php } ?>
            </table>
        </div>

        <div class="bg-slate-950 p-4 w-full max-w-[70%] rounded-md">
            <h2>Lista de Contas a Receber</h2>
            <hr />
            <table class="ms-classic3-main flex flex-col gap-2" style="width: 77%">
                <tr class="flex justify-around">
                    <td class="ms-classic3-tl" style="width: 209px">Documento</td>
                    <td class="ms-classic3-top" style="width: 165px">Valor</td>
                    <td class="ms-classic3-top" style="width: 160px">Status</td>
                    <td class="ms-classic3-top" style="width: 66px">Opções</td>
                </tr>
                <?php

                $CR = new ContasReceber();
                $CRDAO = new ContasReceberDAO();

                $query = $CRDAO->ShowContasReceber($CR);

                while ($reg = $query->fetch_array()) {
                    ?>
                    <tr class="flex justify-around">
                        <td class="ms-classic3-left" style="width:209px">
                            <?= $reg["documento_contasreceber"]; ?>
                        </td>
                        <td class="ms-classic3-even" style="width: 165px">
                            <?= $reg["valor_contasreceber"]; ?>
                        </td>
                        <td class="ms-classic3-even" style="width: 160px">
                            <?= $reg["status_contasreceber"]; ?>
                        </td>
                        <td class="ms-classic3-even flex gap-1" style="width: 66px">
                            <a href="atualizarContaReceber.php?ID=<?= $reg["id_contasreceber"]; ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                    fill="none" stroke="#e2e8f0" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="lucide lucide-square-pen">
                                    <path d="M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                                    <path
                                        d="M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z" />
                                </svg>
                            </a>
                            <a href="apagarContaReceber.php?ID=<?= $reg["id_contasreceber"]; ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                    fill="none" stroke="#e2e8f0" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="lucide lucide-trash-2">
                                    <path d="M3 6h18" />
                                    <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                                    <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                                    <line x1="10" x2="10" y1="11" y2="17" />
                                    <line x1="14" x2="14" y1="11" y2="17" />
                                </svg>
                            </a>
                        </td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </div>
</body>